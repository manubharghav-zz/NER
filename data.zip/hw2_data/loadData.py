import sys

fileName = 'train'

sequence = []
sequences = []
#Make the first start symbol
sequence.append(('<START>','<START>','<START>','<START>'))

for line in open(fileName,'r'):
	line = line.strip()
	if line:
		arr = line.split(' ')
		sequence.append((arr[0],arr[1],arr[2],arr[3]))
	else:
		#Make Stop symbol
		sequence.append(('<STOP>','<STOP>','<STOP>','<STOP>'))
		
		#decode
		print 'Next sequence is:', sequence
		'''
		if len(sequence)>2:
			annotatedSeq = decode(sequence, tagList, gazeteerDict, weightsDict)
			writeToFile(sequence, annotatedSeq, fa)
		'''
		#raw_input()
		sequences.append(sequence)
		sequence = []
		#Make Start Symbol
		sequence.append(('<START>','<START>','<START>','<START>'))

#Make final stop symbol
sequence.append(('<STOP>','<STOP>','<STOP>','<STOP>'))
sequences.append(sequence)
